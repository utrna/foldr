Project MatriX

RNA HEAT: RNA Helix Elimination Acquisition Tool

Directory structure

rheat           <= main project source code files.
    GUI         <= the graphical end for RNA HEAT
    base        <= the backend base for RNA HEAT
    javadoc     <= the javadoc directory
    filter      <= many filter definition classes
    test        <= scratch testing code and some test input files