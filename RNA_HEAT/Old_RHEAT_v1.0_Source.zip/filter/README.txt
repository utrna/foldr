Project MatriX
Directory/Package Definition
GUI         <= the graphical end for RNA HEAT