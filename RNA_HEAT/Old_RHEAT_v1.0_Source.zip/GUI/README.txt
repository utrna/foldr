Project MatriX
Directory/Package Definition
GUI         <= the graphical end for RNA HEAT

    RheatApp            <= the GUI end of the main RNA HEAT program
    HelixGraphicsPanel  <= the display graphics panel for the 2D view.


http://www.mmg.vmei.acad.bg/javaswing/