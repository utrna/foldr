Project MatriX
Directory/Package Definition
base        <= the backend base for RNA HEAT

    Reader  <= reads a file to extract the sequence information.