/*
 * Filter.java
 *
 * Created on April 4, 2003, 2:43 PM
 */

package rheat.test;

/**
 *
 * @author  guru
 */
public interface Filter {
    
    public RNA apply(RNA rna);
}
